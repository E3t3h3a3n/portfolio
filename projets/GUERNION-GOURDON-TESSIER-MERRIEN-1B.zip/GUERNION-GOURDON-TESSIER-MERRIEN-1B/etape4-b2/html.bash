#!/bin/bash

lignespays=$(wc -l < tabtri.csv)

echo "<html>" > tableau.html
echo "<head><meta charset=\"UTF-8\"><title>Tableau Pays</title><style>table {font-size: 8px;}</style></head>" >> tableau.html
echo "<body>" >> tableau.html
echo "<table>" >> tableau.html

for ((i=1; i<$lignespays/2; i++))
do
    ppays1=$(cut -d',' -f1 < tabtri.csv |sed -n "${i}p")
    ppays2=$(cut -d',' -f2 < tabtri.csv |sed -n "${i}p")
    ppays3=$(cut -d',' -f3 < tabtri.csv |sed -n "${i}p")
    ppays4=$(cut -d',' -f4 < tabtri.csv |sed -n "${i}p")
    ppays5=$(cut -d',' -f5 < tabtri.csv |sed -n "${i}p")
    ppays6=$(cut -d',' -f6 < tabtri.csv |sed -n "${i}p")
    var=$((i+46))
    dpays1=$(cut -d',' -f1 < tabtri.csv |sed -n "${var}p")
    dpays2=$(cut -d',' -f2 < tabtri.csv |sed -n "${var}p")
    dpays3=$(cut -d',' -f3 < tabtri.csv |sed -n "${var}p")
    dpays4=$(cut -d',' -f4 < tabtri.csv |sed -n "${var}p")
    dpays5=$(cut -d',' -f5 < tabtri.csv |sed -n "${var}p")
    dpays6=$(cut -d',' -f6 < tabtri.csv |sed -n "${var}p")
    echo "<tr>" >> tableau.html
    for ((y=1; y<7; y++))
    do
        pvar="ppays$y"
        echo "<td>${!pvar}</td>" >> tableau.html

    done
    echo "<td><img src=\"drapeaux/w20/$ppays2.png\" alt=\"Drapeau $ppays2\" /></td>" >> tableau.html
    pprct=$(echo "scale=2; $ppays6*100/1008" | bc)
    echo "<td>$pprct%</td>" >> tableau.html
    echo "<td>          </td>" >> tableau.html
    for ((y=1; y<7; y++))
    do
        dvar="dpays$y"
        echo "<td>${!dvar}</td>" >> tableau.html

    done
    echo "<td><img src=\"drapeaux/w20/$dpays2.png\" alt=\"Drapeau $dpays2\" /></td>" >> tableau.html
    dprct=$(echo "scale=2; $dpays6*100/1008" | bc)
    echo "<td>$dprct%</td>" >> tableau.html
    
    echo "</tr>" >> tableau.html
done

echo "</table>" >> tableau.html
echo "</body>" >> tableau.html
echo "</html>" >> tableau.html

sudo docker run --rm -v "$(pwd):/data" bigpapoo/sae103-html2pdf weasyprint /data/tableau.html /data/tableau.pdf