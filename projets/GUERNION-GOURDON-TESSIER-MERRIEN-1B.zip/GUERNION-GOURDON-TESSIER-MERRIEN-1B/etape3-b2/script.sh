#!/bin/sh
#docker image pull bigpapoo/sae103-imagick
#docker image pull bigpapoo/sae103-wget
#docker image pull bigpapoo/sae103-excel2csv
docker container run --name "wget" -dti --entrypoint /bin/sh --rm  bigpapoo/sae103-wget

docker cp ./telechargerdrapeaux.bash wget:data/script.sh
docker cp ./payspresents wget:data/

docker exec -it wget /bin/bash /data/script.sh

docker cp wget:/data/drapeaux/ ./






docker container stop wget
