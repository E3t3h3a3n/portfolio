#!/bin/bash

lignespays=$(wc -l < payspresents.txt)
mkdir drapeaux
mkdir drapeaux/w20
mkdir drapeaux/80x60
for ((i=1; i<=$lignespays; i++))
do
    paysnom=$(cut -d',' -f2 < payspresents.txt |sed -n "${i}p")
    payscode=$(cut -d',' -f1 < payspresents.txt |sed -n "${i}p")
    echo $paysnom
    wget https://flagcdn.com/w20/$payscode.png -O ./drapeaux/w20/$paysnom.png -q
    wget https://flagcdn.com/80x60/$payscode.png -O ./drapeaux/80x60/$paysnom.png -q

done
