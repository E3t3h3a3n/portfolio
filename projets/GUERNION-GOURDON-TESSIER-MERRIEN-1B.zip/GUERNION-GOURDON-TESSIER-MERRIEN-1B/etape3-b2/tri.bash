#!/bin/bash

sudo docker run --rm -v "$(pwd):/data" bigpapoo/sae103-excel2csv ssconvert "/data/tab.xlsx" /data/tab.csv

rm -f tabavantri.csv tabtemp.csv tabtri.csv

lignespays=$(wc -l < tab.csv)

classement=1
ancientotal=-1

for ((i=4; i<=$lignespays; i++))
do

    nomp=$(cut -d',' -f1 tab.csv | sed -n "${i}p")
    or=$(cut -d',' -f2 tab.csv | sed -n "${i}p")
    argent=$(cut -d',' -f3 tab.csv | sed -n "${i}p")
    bronze=$(cut -d',' -f4 tab.csv | sed -n "${i}p")

    total=$((or + argent + bronze))

    echo "$nomp,$or,$argent,$bronze,$total" >> tabavantri.csv
done

sort -t',' -k5,5nr -k1,1 tabavantri.csv > tabtemp.csv

lignespays2=$(wc -l < tabtemp.csv)

> tabtri.csv 

for ((y=1; y<=lignespays2; y++))
do
    nomp=$(cut -d',' -f1 tabtemp.csv | sed -n "${y}p")
    or=$(cut -d',' -f2 tabtemp.csv | sed -n "${y}p")
    argent=$(cut -d',' -f3 tabtemp.csv | sed -n "${y}p")
    bronze=$(cut -d',' -f4 tabtemp.csv | sed -n "${y}p")
    total=$(cut -d',' -f5 tabtemp.csv | sed -n "${y}p")

    if [ "$total" = "$ancientotal" ]; then
        echo "-,$nomp,$or,$argent,$bronze,$total" >> tabtri.csv
    else
        echo "$classement,$nomp,$or,$argent,$bronze,$total" >> tabtri.csv
        classement=$((classement + 1))
        ancientotal=$total
    fi
done

iconv -f UTF-8 -t UTF-8 tabtri.csv -o tabtri.csv

rm tab.csv tabavantri.csv tabtemp.csv
